<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - GCTU HOSTELS LIMITED</a>
</footer>